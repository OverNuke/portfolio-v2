import type { CSSProperties, MouseEvent } from "react";
import type { Project } from "../../content/types";
import { getProjectCategory, getProjectStatus, STATUS_LABEL } from "../../content/projects";
import type { FieldSlot } from "./fieldLayout";
import { INDEX_TOP } from "./fieldLayout";

/**
 * ONE RECORD ON THE FIELD — a shape on the band, plus its caption column
 * in the foot index, held together in a single `<article>`.
 *
 * WHY ONE ARTICLE FOR TWO SEPARATED THINGS. The disc and its caption sit
 * in different parts of the composition, but they are one record, and a
 * screen reader must be told that: the disc's alt text and the caption's
 * heading, stack, status and link belong to the same project. Splitting
 * them into two sibling regions would put the image in one place and the
 * name of the thing it depicts somewhere else.
 *
 * So the article is `position: absolute; inset: 0` over the WHOLE stage
 * and paints nothing itself; the two children carry the positioning. That
 * means every record's box overlaps every other record's box, which would
 * be an occlusion bug — except the article is `pointer-events: none` and
 * only the chip inside the caption takes them back. Nothing on the field
 * is clickable except that chip, so there is nothing to occlude. See
 * `project-field.css`'s RECORD section.
 *
 * A PANEL IS PRINT, NOT UI — the rule the old panel sheet carried, and it
 * survives the redesign intact. No hover on the disc, no lift, no shadow
 * change, no whole-card link wrap. Exactly one action per record.
 *
 * THE RULE THAT WILL BITE SOMEONE, also unchanged: oxblood on Field Olive
 * is 1.90:1. The band is olive, so nothing oxblood may sit on it — but the
 * foot index is on paper, which is why the chips and their oxblood focus
 * rings live down there and not up on the band.
 */

export type FieldShapeVariant = "fused" | "circle";

export interface FieldRecordProps {
  project: Project;
  slot: FieldSlot;
  /** 1-based position on this field. Drives the decorative tick only. */
  position: number;
  /** The dominant record gets the fused shape and the large caption. */
  primary?: boolean;
  /**
   * Opens the image-expand overlay. Only reached by a record with no repo
   * that does have an image (`RecordAction` decides) — a record with a
   * repo ignores it, and one with neither gets no action at all. Receives
   * the event so the caller can capture `event.currentTarget` as the
   * focus-return target.
   */
  onExpand?: (event: MouseEvent<HTMLButtonElement>) => void;
}

/**
 * Repo link when there is a real one, an expand trigger when there isn't
 * but there is an image worth inspecting closer, nothing when there is
 * neither. Never both.
 *
 * `project.href` is a placeholder ("#") on every current record, so a LIVE
 * chip would ship a dead anchor — flagged by jsx-a11y/anchor-is-valid and
 * misleading either way. The caption's STATUS line already says PRIVATE,
 * so the absence carries the same information the dead link would have.
 */
function RecordAction({
  project,
  onExpand,
}: {
  project: Project;
  onExpand?: (event: MouseEvent<HTMLButtonElement>) => void;
}) {
  if (getProjectStatus(project) === "Live" && project.repo) {
    return (
      <p className="pf-record__action">
        <a className="pf-chip" href={project.repo} target="_blank" rel="noopener noreferrer">
          Repository
          <span className="visually-hidden"> — {project.title}, opens in a new tab</span>
        </a>
      </p>
    );
  }

  if (onExpand && project.image) {
    return (
      <p className="pf-record__action">
        <button type="button" className="pf-chip pf-chip--expand" onClick={onExpand}>
          Expand
          <span className="visually-hidden"> — {project.title} screenshot, view larger</span>
        </button>
      </p>
    );
  }

  return null;
}

/**
 * The disc itself. When `project.image` is absent this renders the
 * no-image fallback the brief's section 9 asks for: a restrained,
 * `[data-motion]`-gated registration animation instead of a photograph
 * (`.pf-shape--empty` in `project-field.css`). No record exercises that
 * branch today; it is a real code path rather than a promise, so the day
 * one does, nothing here has to change.
 */
function Shape({ project, variant }: { project: Project; variant: FieldShapeVariant }) {
  if (!project.image) {
    return <div className={`pf-shape pf-shape--${variant} pf-shape--empty`} aria-hidden="true" />;
  }
  return (
    <div className={`pf-shape pf-shape--${variant}`}>
      <img src={project.image} alt={project.imageAlt} />
    </div>
  );
}

export function FieldRecord({ project, slot, position, primary, onExpand }: FieldRecordProps) {
  const tick = `[${String(position).padStart(2, "0")}]`;
  const { shape, column } = slot;

  const figureStyle: CSSProperties = {
    left: `calc(${shape.cx}% - ${shape.d}% / 2)`,
    top: `${shape.cy}%`,
    width: `${shape.d}%`,
  };

  const capStyle: CSSProperties = {
    left: `${column.x}%`,
    width: `${column.w}%`,
    top: `${INDEX_TOP}%`,
  };

  return (
    <article className="pf-record" data-primary={primary ? "1" : "0"} data-record={position}>
      <div className="pf-record__figure" style={figureStyle}>
        <Shape project={project} variant={primary ? "fused" : "circle"} />
      </div>

      <div className="pf-record__cap" style={capStyle}>
        <p className="pf-record__lead" aria-hidden="true">
          <span className="pf-record__tick">{tick}</span>
          <span className="pf-record__rule" />
          <span className="pf-record__kind">{getProjectCategory(project)}</span>
        </p>
        <h3 className="pf-record__title">{project.title}</h3>
        <p className="pf-record__sub">{project.subtitle}</p>
        <p className="pf-record__meta">
          <span>{project.tags.join(" · ")}</span>
          <span>
            {STATUS_LABEL[getProjectStatus(project)]} · {project.year}
          </span>
        </p>
        <RecordAction project={project} onExpand={onExpand} />
      </div>
    </article>
  );
}
