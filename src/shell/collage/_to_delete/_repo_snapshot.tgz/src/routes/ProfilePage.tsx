import { Panel } from "../components/panel/Panel";
import { ProfilePlate } from "../components/profile-plate/ProfilePlate";
import { ABOUT_PROFILE } from "../content/data";
import { useTurn } from "../turn/useTurn";
import { ROUTES } from "./routes";
import "./profile-page.css";

const route = ROUTES.find((r) => r.pageId === "profile")!;

/**
 * Rebuilt 2026-08-05 on `ProfilePlate` (see that component and the project
 * doc `claude/profile-plate-composition-2026-08-05.md`).
 *
 * The old identity plate + three spec bars are gone: name, role, location
 * and "open to" all live on the composition's data plate now, so repeating
 * them underneath would be duplicate DOM text, not extra information. What
 * stays below the sheet is what the plate deliberately can't hold — the
 * conversational bio (too long for the plate's 34ch measure) and the two
 * CTAs, set on bare paper so the sheet keeps its silence.
 */
export function ProfilePage() {
  const { go } = useTurn();
  const profile = ABOUT_PROFILE;

  return (
    <Panel
      title={route.title}
      status={route.tag}
      metadata={<span>{route.sub}</span>}
      content={
        <div className="profile-page">
          <ProfilePlate profile={profile} statusLabel={profile.status} />

          <div className="profile-page__margin">
            <p className="profile-page__bio">{profile.bio}</p>
            <p className="profile-page__body">{profile.bodyText}</p>

            <div className="profile-page__actions">
              <button
                type="button"
                className="bar bar--accent"
                onClick={(event) => go(profile.ctaPrimary.href, event.currentTarget)}
              >
                <span className="v">{profile.ctaPrimary.label}</span>
              </button>
              <button
                type="button"
                className="bar"
                onClick={(event) => go(profile.ctaSecondary.href, event.currentTarget)}
              >
                <span className="v">{profile.ctaSecondary.label}</span>
              </button>
            </div>
          </div>
        </div>
      }
    />
  );
}
