import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { ABOUT_PROFILE, SKILLS, SOCIAL_LINKS } from "../../content/data";
import { ROUTES } from "../../routes/routes";
import { Canvas } from "./Canvas";

/**
 * Rewritten 2026-08-06 with the "ghost plate" Home. The old assertions
 * covered a composition that no longer exists (the 12x12 collage, three
 * portrait plates, the skills badge field, the fused channel icon strip).
 *
 * `useTurn` is mocked for the same reason as before and as in
 * `NavItem.test.tsx`: the turn machine is covered end-to-end in
 * `TurnProvider.test.tsx`; this file only proves Canvas composes the right
 * content and wires the right controls.
 *
 * What is deliberately asserted here is the ACCESSIBILITY CONTRACT, not
 * the layout — layout is `collage.css`'s job and `collage.test.ts` /
 * `audit:collage` cover it. The four things that would silently break and
 * that nothing else would catch:
 *   · the split masthead must not reach the accessibility tree (it would
 *     announce the name twice, fragmented);
 *   · contact must be reachable now that it is off the module index;
 *   · the rail must follow `Skill.core` rather than a literal;
 *   · channel links must be named by their address, not by "GitHub".
 */
const goMock = vi.hoisted(() => vi.fn());

vi.mock("../../turn/useTurn", () => ({
  useTurn: () => ({ go: goMock }),
}));

const CORE_SKILLS = SKILLS.filter((skill) => skill.core);
const MODULES = ROUTES.filter((route) => route.pageId !== "contact");
const CONTACT_ROUTE = ROUTES.find((route) => route.pageId === "contact")!;

describe("Canvas", () => {
  beforeEach(() => {
    goMock.mockClear();
  });

  it("exposes the full name once, as the page heading", () => {
    render(<Canvas />);

    expect(
      screen.getByRole("heading", {
        level: 1,
        name: `${ABOUT_PROFILE.firstName} ${ABOUT_PROFILE.lastName}`,
      }),
    ).toBeInTheDocument();

    // The two visible lines are decorative fragments of that heading. If
    // either reaches the tree the name is announced twice, split.
    expect(screen.queryByText("GARC")).not.toBeInTheDocument();
    expect(screen.queryByText("Kevin Sebastián Frías")).not.toBeInTheDocument();
  });

  it("renders one NavItem per routed module and omits contact from the index", () => {
    render(<Canvas />);
    const nav = screen.getByRole("navigation", { name: "Primary" });

    for (const route of MODULES) {
      const button = screen.getByRole("button", { name: new RegExp(route.title, "i") });
      expect(nav).toContainElement(button);
    }

    // Contact keeps its route; it is simply not a module row, because its
    // channels are on this page.
    expect(
      screen.queryByRole("button", { name: new RegExp(CONTACT_ROUTE.title, "i") }),
    ).not.toBeInTheDocument();
  });

  it("NavItems drive the turn machine", async () => {
    const user = userEvent.setup();
    render(<Canvas />);
    const button = screen.getByRole("button", { name: /profile/i });

    await user.click(button);

    expect(goMock).toHaveBeenCalledTimes(1);
    expect(goMock).toHaveBeenCalledWith("/profile", button);
  });

  it("keeps /contact reachable through the availability chip", async () => {
    const user = userEvent.setup();
    render(<Canvas />);
    const chip = screen.getByRole("button", { name: new RegExp(ABOUT_PROFILE.status, "i") });

    await user.click(chip);

    expect(goMock).toHaveBeenCalledWith(CONTACT_ROUTE.path, chip);
  });

  it("renders the stack rail from Skill.core, and states the remainder", () => {
    render(<Canvas />);
    const rail = screen.getByRole("complementary", { name: "Core stack" });

    expect(CORE_SKILLS.length).toBeGreaterThan(0);
    for (const skill of CORE_SKILLS) {
      expect(screen.getByText(skill.name)).toBeInTheDocument();
    }

    // A skill without the flag must not appear — that is the whole point
    // of the flag living in data.ts.
    const unlisted = SKILLS.filter((skill) => !skill.core);
    for (const skill of unlisted) {
      expect(screen.queryByText(skill.name)).not.toBeInTheDocument();
    }

    expect(rail).toHaveTextContent(new RegExp(`\\+ 0?${unlisted.length} more`, "i"));
  });

  it("names each channel link by its address, not by its platform", () => {
    render(<Canvas />);

    for (const link of SOCIAL_LINKS) {
      const address = link.href
        .replace(/^mailto:/, "")
        .replace(/^https?:\/\//, "")
        .replace(/^www\./, "")
        .replace(/\/$/, "");

      const anchor = screen.getByRole("link", { name: address });
      expect(anchor).toHaveAttribute("href", link.href);
    }
  });

  it("marks the photograph decorative", () => {
    const { container } = render(<Canvas />);
    const img = container.querySelector(".hm-hero img");

    // It duplicates the heading and carries nothing the heading does not —
    // same call as the profile plate's portrait.
    expect(img).toHaveAttribute("alt", "");
  });
});
