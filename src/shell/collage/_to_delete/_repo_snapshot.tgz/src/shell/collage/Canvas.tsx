import { ABOUT_PROFILE, SKILLS, SOCIAL_LINKS } from "../../content/data";
import { ROUTES } from "../../routes/routes";
import { GithubIcon, LinkedinIcon, MailIcon } from "../../components/social-icon/SocialIcon";
import { useTurn } from "../../turn/useTurn";
import { NavItem } from "./NavItem";
import heroImg from "../../assets/plates/portrait/hero-blur.png";
import "./home.css";

/**
 * HOME — "GHOST PLATE" (rewritten 2026-08-06, Keff).
 *
 * Supersedes the doc-12 collage Home entirely: the 12x12 grid, the three
 * photo/detail plates, the skills badge field, the fused channel icon
 * strip and the serial/barcode block are all gone. Design record:
 * `claude/home-y2k-editorial-directions-2026-08-06.md` (direction A, chosen
 * over B/DECK 99 and C/SPREAD) and `claude/home-icon-system-2026-08-06.md`
 * (the margin rail and the channel glyphs).
 *
 * The composition, in the order it reads:
 *
 *   1. ONE PHOTOGRAPH, bleeding off the right edge, multiplied into the
 *      paper. `mix-blend-mode: multiply` is the load-bearing trick of the
 *      whole page: the studio backdrop multiplies to ~paper and disappears,
 *      so the figure prints onto the sheet instead of sitting on it as a
 *      rectangle. It is also what lets the masthead sit UNDERNEATH the
 *      photograph and still read.
 *   2. THE MASTHEAD, LT Superior Serif ExtraBold, under the figure — the
 *      dark sweater swallows the letters it crosses and the light backdrop
 *      lets them through. The one accented glyph is olive.
 *   3. THE OLIVE INDEX PLATE, printed over the photograph at -1.15deg with
 *      a second `--field-olive-deep` pass behind it for registration drift.
 *      It carries the real `NavItem` list.
 *   4. THE STACK RAIL down the left margin — `SKILLS` filtered to `core`.
 *   5. THE CONTACT STRIP at the foot, imported from direction C.
 *
 * WHY CONTACT IS ON HOME AND PROJECTS ARE NOT. Direction C's foot strip
 * originally listed project records. Home listing them would repeat
 * module 02's entire job — the same duplication the 2026-08-03 third pass
 * removed when it stopped Home rendering `PROJECTS[].image`. Contact, by
 * contrast, has just left the module index, so this strip is the only
 * place those addresses appear. A component that duplicates a module is
 * decoration; a component that is the sole home of its content is
 * structure.
 *
 * `/contact` REMAINS A ROUTE (Keff, 2026-08-06) — it is simply not in the
 * index. It stays reachable by deep link, by `ABOUT_PROFILE.ctaPrimary`,
 * and by the availability chip below, which is why that chip is a real
 * `NavItem`-style button driving the turn machine rather than decoration.
 *
 * ALL placement lives in `home.css` (design D5). This component applies
 * class names only — never an inline style, never a pixel top/left.
 */

/** The index shows routed *modules*. Contact is reachable, but its channels
 *  live on this page, so listing it would say the same thing twice. */
const MODULES = ROUTES.filter((route) => route.pageId !== "contact");
const CONTACT_ROUTE = ROUTES.find((route) => route.pageId === "contact");

/** Curated in `data.ts`, not here — see `Skill.core`. Home and any future
 *  skills surface read the same flag, so they cannot drift. */
const CORE_SKILLS = SKILLS.filter((skill) => skill.core);
const UNLISTED_SKILLS = SKILLS.length - CORE_SKILLS.length;

const CHANNEL_ICONS = { GitHub: GithubIcon, LinkedIn: LinkedinIcon, Email: MailIcon } as const;

/** `mailto:ksfgarcia24@gmail.com` -> `ksfgarcia24@gmail.com`,
 *  `https://github.com/OverNuke` -> `github.com/OverNuke`. The address IS
 *  the link text — it is a better accessible name than "GitHub" because a
 *  link-list read-out then says where it actually goes. */
function channelAddress(href: string): string {
  return href
    .replace(/^mailto:/, "")
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/\/$/, "");
}

export function Canvas() {
  const { go } = useTurn();

  return (
    <div className="canvas">
      {/* Decorative: the photograph duplicates the heading and carries no
          information of its own — same call as the profile plate. */}
      <div className="hm-hero" aria-hidden="true">
        <img src={heroImg} alt="" />
      </div>

      <div className="hm-seam" aria-hidden="true" />

      <header className="hm-identity">
        <p className="hm-eyebrow">
          {ABOUT_PROFILE.role} — underground portfolio
        </p>
        <h1 className="hm-name">
          <span className="visually-hidden">
            {ABOUT_PROFILE.firstName} {ABOUT_PROFILE.lastName}
          </span>
          {/* The two visible lines are decorative fragments of the name
              above them; announcing them would repeat it letter-split. */}
          <span className="hm-name__given" aria-hidden="true">
            Kevin Sebastián Frías
          </span>
          <span className="hm-name__family" aria-hidden="true">
            GARC<i>Í</i>A
          </span>
        </h1>

        <div className="hm-rule" aria-hidden="true" />
        <p className="hm-summary">{ABOUT_PROFILE.summary}</p>
        <p className="hm-bio">{ABOUT_PROFILE.bio}</p>
      </header>

      <nav className="hm-plate" aria-label="Primary">
        <span className="hm-plate__tick" aria-hidden="true">
          [01]
        </span>
        <h2 className="hm-plate__title">Module index</h2>
        <ul className="hm-index">
          {MODULES.map((route) => (
            <li key={route.pageId}>
              <NavItem route={route} />
            </li>
          ))}
        </ul>
        <div className="hm-plate__foot" aria-hidden="true">
          <span>2026</span>
          <span>[03]</span>
        </div>
      </nav>

      {/* Chips are inert text, not controls — there is no skills route to
          send them to. The glyphs the first cut carried were removed on
          2026-08-06: nine olive marks down the edge read as colour weight
          and pulled the page's only accent away from the plate. */}
      <aside className="hm-rail" aria-label="Core stack">
        <span className="hm-rail__label">Stack</span>
        <ul>
          {CORE_SKILLS.map((skill) => (
            <li className="hm-chip" key={skill.name}>
              <em>{skill.name}</em>
            </li>
          ))}
        </ul>
        {UNLISTED_SKILLS > 0 && (
          <span className="hm-rail__tail">
            + {String(UNLISTED_SKILLS).padStart(2, "0")} more
          </span>
        )}
      </aside>

      <section className="hm-channels" aria-labelledby="hm-channels-title">
        <div className="hm-channels__head">
          <h2 id="hm-channels-title">Contact channels</h2>
          {CONTACT_ROUTE && (
            <button
              type="button"
              className="hm-status"
              data-page={CONTACT_ROUTE.pageId}
              onClick={(event) => go(CONTACT_ROUTE.path, event.currentTarget)}
            >
              <span className="hm-status__dot" aria-hidden="true" />
              {ABOUT_PROFILE.status}
            </button>
          )}
        </div>
        <ul>
          {SOCIAL_LINKS.map((link, index) => {
            const Icon = CHANNEL_ICONS[link.label as keyof typeof CHANNEL_ICONS];
            return (
              <li key={link.label}>
                <span className="hm-channels__ic" aria-hidden="true">
                  {Icon && <Icon aria-hidden="true" />}
                </span>
                <span className="hm-channels__id" aria-hidden="true">
                  CH {String(index + 1).padStart(2, "0")}
                </span>
                <a className="hm-channels__nm" href={link.href}>
                  {channelAddress(link.href)}
                </a>
                <span className="hm-channels__meta">{link.label}</span>
              </li>
            );
          })}
        </ul>
      </section>

      <p className="hm-serial" aria-hidden="true">
        SER. KSFG–0001–ARCH · SHEET 01/01
      </p>
      <span className="hm-reticle hm-reticle--tl" aria-hidden="true" />
      <span className="hm-reticle hm-reticle--br" aria-hidden="true" />
    </div>
  );
}
