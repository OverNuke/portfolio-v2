import { readFileSync } from "node:fs";
import { join } from "node:path";
import postcss, { type Container, type Rule } from "postcss";
import { describe, expect, it } from "vitest";

/* 2026-08-06: Home's placement moved to `home.css` — a new composition on
   a new filename rather than an in-place rewrite of `collage.css`, whose
   grid this Home no longer uses. `collage.css` and `skills-collage.css`
   are both still on disk and BOTH ARE NOW UNREFERENCED (nothing imports
   either); delete them, along with `SkillsCollage.tsx`, `collageSeeds.ts`,
   `useCollageSeed.ts` and `components/skill-badge/`, in a cleanup pass. */
const STYLESHEET_PATHS = [join(__dirname, "home.css")];

function parse() {
  const css = STYLESHEET_PATHS.map((path) => readFileSync(path, "utf-8")).join("\n");
  return postcss.parse(css);
}

function isRule(node: Container | undefined): node is Rule {
  return !!node && "selector" in node;
}

/**
 * Task 3.1 (sdd/phase2-app-shell), design D5 ("collage.css is the single
 * placement source of truth" — parsed with postcss, not asserted on
 * inline styles/TS layout tables; regex over CSS is rejected as brittle).
 * These four checks map 1:1 to spec #67's collage-canvas scenarios:
 * grid-area-only placement, the ±2° rotation cap (--rot-max), and the
 * interactive (20-30) z-index band for nav plates.
 */
describe("home.css", () => {
  const root = parse();

  // (a) Every block placed on the canvas must declare a grid-area. The
  // 2026-08-06 "ghost plate" Home is a 4-area grid rather than a 12x12
  // collage, but the rule it enforces is unchanged: placement is CSS's
  // job, declared once, never an inline style. The photograph, the seam
  // and the margin reticles are absolutely positioned instead — they are
  // decorative, aria-hidden, and outside the grid on purpose, which is
  // exactly what check (b) below pins down.
  const PLACEMENT_SELECTORS = [".hm-identity", ".hm-plate", ".hm-rail", ".hm-channels"];

  it.each(PLACEMENT_SELECTORS)("%s declares a grid-area", (selector) => {
    let found = false;
    root.walkRules(selector, (rule) => {
      found = true;
      const hasGridArea = rule.nodes.some(
        (node) => node.type === "decl" && node.prop === "grid-area",
      );
      expect(hasGridArea, `${selector} must declare grid-area`).toBe(true);
    });
    expect(found, `${selector} rule not found in home.css`).toBe(true);
  });

  // (b) No rule anywhere may use pixel top/left placement — grid-area is
  // the only placement mechanism. (`.hero` used to be this check's one
  // documented exception, positioned via the `inset` shorthand rather than
  // `top`/`left` — moot as of 2026-08-03, second pass: `.hero` is gone.)
  it("no rule uses top/left placement", () => {
    const offenders: string[] = [];
    root.walkDecls(/^(top|left)$/, (decl) => {
      const rule = isRule(decl.parent) ? decl.parent.selector : "(unknown)";
      offenders.push(`${rule}: ${decl.prop}`);
    });
    expect(offenders).toEqual([]);
  });

  // (c) Every authored --rot custom property stays within the ±2deg cap
  // (--rot-max, docs/12_COLLAGE_SYSTEM.md).
  it("every --rot custom property stays within the +/-2deg cap", () => {
    const offenders: string[] = [];
    root.walkDecls("--rot", (decl) => {
      const match = /^(-?\d+(?:\.\d+)?)deg$/.exec(decl.value.trim());
      const rule = isRule(decl.parent) ? decl.parent.selector : "(unknown)";
      if (!match) {
        offenders.push(`${rule}: unparseable --rot value "${decl.value}"`);
        return;
      }
      if (Math.abs(Number(match[1])) > 2) {
        offenders.push(`${rule}: ${decl.value}`);
      }
    });
    expect(offenders).toEqual([]);
  });

  // (d) z-index values fall within the band matching what they carry —
  // interactive (the index plate and the channel strip, both real
  // controls) vs content (identity, stack rail — inert) vs decorative
  // (photograph, seam, margin chrome) — docs/12_COLLAGE_SYSTEM.md's
  // stack-order-follows-meaning rule (interactive > content > decorative).
  // An explicit table, not a single "nav" regex, so a mis-banded new plate
  // fails loudly instead of shipping unenforced.
  const Z_INDEX_BANDS = [
    { pattern: /hm-(hero|seam|serial|reticle)/i, min: 1, max: 9 },
    { pattern: /hm-(identity|rail)/i, min: 10, max: 19 },
    { pattern: /hm-(plate|channels)/i, min: 20, max: 30 },
  ];

  it("z-index values fall within their meaning's band", () => {
    const offenders: string[] = [];
    root.walkDecls("z-index", (decl) => {
      if (!isRule(decl.parent)) return;
      const selector = decl.parent.selector;
      const band = Z_INDEX_BANDS.find(({ pattern }) => pattern.test(selector));
      if (!band) return;
      const value = Number(decl.value);
      if (Number.isNaN(value) || value < band.min || value > band.max) {
        offenders.push(`${selector}: ${decl.value} (expected ${band.min}-${band.max})`);
      }
    });
    expect(offenders).toEqual([]);
  });
});

/**
 * Retired from Home on 2026-08-06 and NOT re-pinned here: `.identity-plate`,
 * `.nav-stack`, `.skills-collage`, `.plate-sit`/`.plate-work`/`.plate-detail`,
 * `.socials`, `.serial-block`. They are gone from `collage.css` entirely
 * rather than exempted — see `home.css`'s header for the design record.
 *
 * The shared `.bar--accent` / `.plate` skins (ProfilePage's CTA button,
 * featured ProjectCards) live in `src/styles/plate.css` and are untouched;
 * nothing in this file layers on top of them any more, so their coverage
 * belongs with the pages that actually use them.
 */
